package com.forgewareinc.elrol.guiElevator;

public class ModInfo {

	public static final String MODID = "guielevator";
	
	public static final String NAME = "Elrol's GUI Elevator";
	
	public static final String VERSION = "1.3";
	
	
	
}
