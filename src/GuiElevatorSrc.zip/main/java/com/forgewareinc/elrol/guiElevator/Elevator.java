package com.forgewareinc.elrol.guiElevator;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.texture.IIconRegister;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.IIcon;
import net.minecraft.world.World;

public class Elevator extends BlockContainer {

	
	public IIcon side;
	protected IIcon field_150164_N;
    
	public Elevator(String name, CreativeTabs tab, float hardness, float resistance, SoundType stepSound) {
		super(Material.iron);
		this.setBlockName(name);
		this.setHardness(hardness);
		this.setResistance(resistance);
		this.setBlockTextureName(ModInfo.MODID + ":" + name);
		this.setCreativeTab(tab);
		this.setStepSound(stepSound);
		
	}
	
	public boolean isNormalCube()
    {
        return false;
    }
	
	public boolean onBlockActivated(World world, int x, int y, int z, EntityPlayer player, int par1, float par2, float par3, float par4)
    {
		if(world.isRemote){
			if(player.isSneaking()){
				player.openGui(ElevatorMain.instance, 1, world, x, y, z);
				return true;
			}else{
				player.openGui(ElevatorMain.instance, 0, world, x, y, z);
				return true;
			}
			
		}
		else{
			return true;	
		}
    }

	@Override
	public TileEntity createNewTileEntity(World p_149915_1_, int p_149915_2_) {
		try{
			return new TileEntityElevator();	
		}catch (Exception var3){
			throw new RuntimeException(var3);
		}
		
	}
	
	public boolean hasTileEntity(int meta){
		return true;
	}
	
	@SideOnly(Side.CLIENT)
	public void registerBlockIcons(IIconRegister icon){
		this.blockIcon = icon.registerIcon(this.textureName);
		this.side = icon.registerIcon(this.textureName + "_face");
	}
	
	@SideOnly(Side.CLIENT)
	public IIcon getIcon(int side, int meta){
		if(side == meta){
			return this.side;
		}else{
			return this.blockIcon;
		}
	}
	
	public int onBlockPlaced(World world, int x, int y, int z, int side, float hitX, float hitY, float hitZ, int meta)
    {
		world.setBlockMetadataWithNotify(x, y, z, side, 2);
		return side;
    }
	
	public void HandlePacket(EntityPlayer player, int x, int y, int z, String value, byte extra){
		TileEntity te = player.worldObj.getTileEntity(x, y, z);
		if(te != null && te instanceof TileEntityElevator){
			((TileEntityElevator)te).name = value;
			((TileEntityElevator)te).markDirty();;
		}
	}
	
}
