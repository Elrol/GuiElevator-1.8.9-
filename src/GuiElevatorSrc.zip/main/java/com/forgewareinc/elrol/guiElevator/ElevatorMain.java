package com.forgewareinc.elrol.guiElevator;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraftforge.oredict.ShapedOreRecipe;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.Mod.Instance;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;



@Mod(modid = ModInfo.MODID, name = ModInfo.NAME,version = ModInfo.VERSION)
public class ElevatorMain
{
	public static Block elevator;
	public static final ElevatorPacketSystem packetSystem = new ElevatorPacketSystem(ModInfo.MODID);
	
	@Instance
	public static ElevatorMain instance = new ElevatorMain();
	
    @EventHandler
    public void preInit(FMLPreInitializationEvent event)
    {
    	packetSystem.registerPacket(NamingPacket.TeleportPacketHandler.class, NamingPacket.class, Side.SERVER);
    	packetSystem.registerPacket(TeleportPacket.TeleportPacketHandler.class, TeleportPacket.class, Side.SERVER);
    }
    
    @EventHandler
    public void init(FMLInitializationEvent event)
    {
    	NetworkRegistry.INSTANCE.registerGuiHandler(ElevatorMain.instance, new ModGUIHandler());
    	elevator = new Elevator("guielevator", CreativeTabs.tabTransport, 3.0F, 6.0F, Block.soundTypeMetal);
    	GameRegistry.registerBlock(elevator, "guielevator");
    	GameRegistry.registerTileEntity(TileEntityElevator.class, "elevatorBlock");
    	TileEntity.addMapping(TileEntityElevator.class, ModInfo.MODID + "TileEntityElevator");
    	recipes();
	}
    
    public void recipes(){
    	System.out.println("Register Recipe");
    	GameRegistry.addRecipe(new ItemStack(elevator, 1, 0), "xyx", "yzy", "xyx", 'x', Items.iron_ingot, 'y', Blocks.wool, 'z', Items.ender_pearl);
    
    }
}
