package com.forgewareinc.elrol.guiElevator;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import io.netty.buffer.ByteBuf;
import net.minecraft.block.Block;
import net.minecraft.command.PlayerNotFoundException;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.ChatComponentText;

public class NamingPacket implements IMessage {

	static int x;
	static int y;
	static int z;
	private static String value;
	private static byte extra;
	
	
	public NamingPacket(){}
	
	public NamingPacket(int x, int y, int z, String value, byte extra){
		this.x = x;
		this.y = y;
		this.z = z;
		this.value = value;
		this.extra = extra;
	}
	
	public static void sendToServer(IMessage packet){
		ElevatorMain.packetSystem.instance().sendToServer(packet);
	}
	
	public static void send(int X, int Y, int Z, String name, byte extra){
		sendToServer(new NamingPacket(X, Y, Z, name, extra));
	}
	
	@Override
	public void fromBytes(ByteBuf buf) {
		x = buf.readInt();
		y = buf.readInt();
		z = buf.readInt();
		value = ByteBufUtils.readUTF8String(buf);
		extra = buf.readByte();
		
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(x);
		buf.writeInt(y);
		buf.writeInt(z);
		ByteBufUtils.writeUTF8String(buf, value);
		buf.writeInt(extra);
	}
	
	@SideOnly(Side.CLIENT)
	public static void hpc(MessageContext ctx){
		handlePacket(FMLClientHandler.instance().getClient().thePlayer, ctx.side);
	}
	
	public static void handlePacket(EntityPlayer player, Side side){
		Block block = player.worldObj.getBlock(x,y,z);
		if(block != null && block instanceof Elevator){
			((Elevator)block).HandlePacket(player, x, y, z, value, extra);
		}
	}
	
	public static class TeleportPacketHandler implements IMessageHandler<NamingPacket, IMessage>{

		@Override
		public IMessage onMessage(NamingPacket message, MessageContext ctx) {
			switch (ctx.side)
			{
			case CLIENT:
				hpc(ctx);
				break;
			case SERVER:
				handlePacket(ctx.getServerHandler().playerEntity, ctx.side);
				break;
				default:
			}
			
			return null;
			 
		}
	}
}
